#include "stm32f0xx.h"

//--------- PWM INI ----------
void pwm_ini(){
  RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;
  TIM3->ARR = 47999;
  TIM3->CR1 |= TIM_CR1_ARPE;
  // TIM3 Chanel 3 for led PC8 (blue)
  TIM3->CCR3 = 2400;
  TIM3->CCMR2 |= TIM_CCMR2_OC3M_1 | TIM_CCMR2_OC3M_2;
  TIM3->CCMR2 |= TIM_CCMR2_OC3PE;
  // TIM3 Chanel 4 for led PC9 (green)
  TIM3->CCR4 = 48000;
  TIM3->CCMR2 |= TIM_CCMR2_OC4M_1 | TIM_CCMR2_OC4M_2;
  TIM3->CCMR2 |= TIM_CCMR2_OC4PE;

  TIM3->EGR |= TIM_EGR_UG;
  TIM3->CCER |= TIM_CCER_CC3E;
  TIM3->CCER |= TIM_CCER_CC4E;

  TIM3->CR1 |= TIM_CR1_CEN;
}

//--------- LED INI ----------
void led_ini() {
  RCC->AHBENR |= RCC_AHBENR_GPIOCEN;
  GPIOC->MODER |= GPIO_MODER_MODER8_1 | GPIO_MODER_MODER9_1;
  GPIOC->OTYPER = 0;
  GPIOC->OSPEEDR = 0;
}

//--------- BUTTON INI ----------
void button_ini() {
  RCC->AHBENR |= RCC_AHBENR_GPIOAEN;
}

int main(void) {
  led_ini();
  button_ini();
  pwm_ini();
  // ...

  uint8_t i = 0;
  uint8_t level = 0;

  while (1) {
    if ((GPIOA->IDR & GPIO_IDR_0)) {
      i++;
      if (i == 10) {
        level++; // level değişkenini güncelle
        switch (level) {
          case 1:
            TIM3->CCR3 = 14400;
            TIM3->CCR4 = 33600;
            break;
          case 2:
            TIM3->CCR3 = 26400;
            TIM3->CCR4 = 26400;
            break;
          case 3:
            TIM3->CCR3 = 33600;
            TIM3->CCR4 = 14400;
            break;
          case 4:
            TIM3->CCR3 = 48000;
            TIM3->CCR4 = 2400;
            break;
          case 5:
            TIM3->CCR3 = 2400;
            TIM3->CCR4 = 48000;
            level = 0; // level 5'ten sonra sıfırla
        }
        i = 0;
        while ((GPIOA->IDR & GPIO_IDR_0));
      }
    } else {
      i = 0;
    }
  }

}


/*
 *
 * Tabii ki, aşağıda verilen kodu satır satır açıklayayım:

1. `#include "stm32f0xx.h"`: STM32F0xx serisi mikrodenetleyiciyi programlamak için gerekli olan STMicroelectronics'in HAL kütüphanesini içeri aktarır.

2. `void pwm_ini()`: PWM (Pulse Width Modulation) yapılandırma fonksiyonunun başlangıcıdır. Bu fonksiyon, TIM3 periferini yapılandırır ve iki LED'i kontrol etmek için kullanılır.

3. `RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;`: TIM3 periferini etkinleştirir. TIM3, Advanced Peripheral Bus 1 (APB1) üzerindedir.

4. `TIM3->ARR = 47999;`: TIM3 zamanlayıcısının otomatik yeniden yükleme değerini ayarlar. Bu değer, zamanlayıcının dönüş hızını kontrol eder.

5. `TIM3->CR1 |= TIM_CR1_ARPE;`: Otomatik yeniden yükleme özelliklerini etkinleştirir, bu da ARR değerinin anında etkinleştirilmesini sağlar.

6. `TIM3->CCR3 = 2400;`: TIM3'nin Kanal 3'ünün karşılaştırma değerini ayarlar. Bu, mavi LED'in parlaklığını kontrol eder.

7. `TIM3->CCMR2 |= TIM_CCMR2_OC3M_1 | TIM_CCMR2_OC3M_2;`: TIM3'nin Kanal 3'ünün PWM modunu ayarlar.

8. `TIM3->CCMR2 |= TIM_CCMR2_OC3PE;`: TIM3'nin Kanal 3'ünün önceden yükleme özelliğini etkinleştirir.

9. `TIM3->CCR4 = 48000;`: TIM3'ün Kanal 4'ünün karşılaştırma değerini ayarlar. Bu, yeşil LED'in parlaklığını kontrol eder.

10. `TIM3->CCMR2 |= TIM_CCMR2_OC4M_1 | TIM_CCMR2_OC4M_2;`: TIM3'ün Kanal 4'ünün PWM modunu ayarlar.

11. `TIM3->CCMR2 |= TIM_CCMR2_OC4PE;`: TIM3'ün Kanal 4'ünün önceden yükleme özelliğini etkinleştirir.

12. `TIM3->EGR |= TIM_EGR_UG;`: TIM3 güncelleme etkinleştirme kaydını yeniler.

13. `TIM3->CCER |= TIM_CCER_CC3E;`: TIM3'ün Kanal 3'ünü etkinleştirir, bu da mavi LED'i kontrol eder.

14. `TIM3->CCER |= TIM_CCER_CC4E;`: TIM3'ün Kanal 4'ünü etkinleştirir, bu da yeşil LED'i kontrol eder.

15. `TIM3->CR1 |= TIM_CR1_CEN;`: TIM3'ü etkinleştirir, bu da PWM çıkışını başlatır.

16. `void led_ini()`: LED yapılandırma fonksiyonunun başlangıcıdır. Bu fonksiyon, PC8 ve PC9 pinlerini çıkış olarak ayarlar.

17. `RCC->AHBENR |= RCC_AHBENR_GPIOCEN;`: GPIOC portunu etkinleştirir.

18. `GPIOC->MODER |= GPIO_MODER_MODER8_1 | GPIO_MODER_MODER9_1;`: PC8 ve PC9 pinlerini alternatif fonksiyon olarak ayarlar, bu da TIM3 PWM çıkışlarına bağlıdır.

19. `GPIOC->OTYPER = 0;`: Çıkış tipini düşük olarak ayarlar (Open Drain değil).

20. `GPIOC->OSPEEDR = 0;`: GPIO hızını düşük hıza ayarlar.

21. `void button_ini()`: Buton yapılandırma fonksiyonunun başlangıcıdır. Bu fonksiyon, PA0 pinini giriş olarak ayarlar.

22. `RCC->AHBENR |= RCC_AHBENR_GPIOAEN;`: GPIOA portunu etkinleştirir.

23. `uint8_t i = 0;` ve `uint8_t level = 0;`: İki tamsayı değişkeni oluşturur, `i` sayacı ve `level` PWM seviyesini saklar.

24. `while (1) {`: Sonsuz bir döngü başlatır.

25. `if ((GPIOA->IDR & GPIO_IDR_0)) {`: Eğer PA0 pini düşükse (buton basıldıysa):

26. `i++;`: Sayacı artırır.

27. `if (i == 10) {`: Eğer sayac 10'a ulaştıysa:

28. `level++; // level değişkenini güncelle`: PWM seviyesini artırır.

29. `switch (level) {`: `level` değişkenine göre bir dizi PWM değeri ayarlar:

   - Eğer `level` 1 ise mavi LED'i parlaklaştırır, yeşil LED'i azaltır.
   - Eğer `level` 2 ise her iki LED'i eşit parlaklıkta ayarlar.
   - Eğer `level` 3 ise mavi LED'i azaltır, yeşil LED'i parlaklaştırır.
   - Eğer `level` 4 ise mavi LED'i sıfırlar, yeşil LED'i en parlak seviyeye ayarlar.
   - Eğer `level` 5 ise `level`'ı sıfırlar (döngüyü tekrar başlatır).

30. `i = 0;`: Sayacı sıfırlar.

31. `while ((GPIOA->IDR & GPIO_IDR_0));`: Butonun serbest bırakılmasını bekler.

32. `} else {`: Eğer buton basılmamışsa:

33. `i = 0;`: Sayacı sıfırlar.

34. `}`

Bu kod, bir buton kullanarak iki LED'in parlaklığını kontrol eden basit bir uygulamayı gerçekleştirir. Butona her basıldığında, LED'lerin parlaklığı değişir ve belirli bir seviyeye ulaştığında sıfırlanır. Bu sayede LED'lerin parlaklığını değiştirerek farklı efektler oluşturabilirsiniz.
*/

